module.exports = {
  content: [
    "./templates/**/*.html.twig",
    "./**/*.html.twig",
    "./js/**/*.js",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
